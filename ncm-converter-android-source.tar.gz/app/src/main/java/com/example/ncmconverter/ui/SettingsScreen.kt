package com.example.ncmconverter.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ncmconverter.util.AppPrefs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val scrollState = rememberScrollState()
    val focusManager = LocalFocusManager.current

    var themeMode by remember { mutableStateOf(AppPrefs.themeMode) }
    var customPath by remember { mutableStateOf(AppPrefs.customPath) }
    var manualSave by remember { mutableStateOf(AppPrefs.manualSave) }
    var enableLyric by remember { mutableStateOf(AppPrefs.enableLyric) }
    var lyricMode by remember { mutableStateOf(AppPrefs.lyricMode) }
    var lyricApiBaseUrl by remember { mutableStateOf(AppPrefs.lyricApiBaseUrl) }
    var lyricRealIP by remember { mutableStateOf(AppPrefs.lyricRealIP) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("设置") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "返回")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(scrollState)
                .padding(bottom = 32.dp)
        ) {
            SectionHeader("主题")
            Text("主题模式", modifier = Modifier.padding(start = 16.dp, top = 8.dp), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                ThemeChip("跟随系统", themeMode == AppPrefs.THEME_SYSTEM) {
                    themeMode = AppPrefs.THEME_SYSTEM; AppPrefs.themeMode = themeMode
                }
                ThemeChip("浅色", themeMode == AppPrefs.THEME_LIGHT) {
                    themeMode = AppPrefs.THEME_LIGHT; AppPrefs.themeMode = themeMode
                }
                ThemeChip("深色", themeMode == AppPrefs.THEME_DARK) {
                    themeMode = AppPrefs.THEME_DARK; AppPrefs.themeMode = themeMode
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

            SectionHeader("导出")
            OutlinedTextField(
                value = customPath,
                onValueChange = { customPath = it; AppPrefs.customPath = it },
                label = { Text("保存路径") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii, imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() })
            )
            SettingSwitch(
                title = "手动点击保存",
                subtitle = if (manualSave) "转换完成后需手动点击保存按钮" else "转换完成后自动保存",
                checked = manualSave,
                onCheckedChange = { manualSave = it; AppPrefs.manualSave = it }
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

            SectionHeader("歌词")
            SettingSwitch(
                title = "自动嵌入歌词",
                subtitle = if (enableLyric) "转换完成后自动搜索并嵌入歌词" else "不自动获取歌词",
                checked = enableLyric,
                onCheckedChange = { enableLyric = it; AppPrefs.enableLyric = it }
            )

            if (enableLyric) {
                Text("歌词模式", modifier = Modifier.padding(start = 16.dp, top = 8.dp), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    LyricModeChip("混合模式", lyricMode == AppPrefs.LYRIC_MODE_MERGED) {
                        lyricMode = AppPrefs.LYRIC_MODE_MERGED; AppPrefs.lyricMode = lyricMode
                    }
                    LyricModeChip("原文", lyricMode == AppPrefs.LYRIC_MODE_RAW) {
                        lyricMode = AppPrefs.LYRIC_MODE_RAW; AppPrefs.lyricMode = lyricMode
                    }
                    LyricModeChip("翻译", lyricMode == AppPrefs.LYRIC_MODE_TRANSLATED) {
                        lyricMode = AppPrefs.LYRIC_MODE_TRANSLATED; AppPrefs.lyricMode = lyricMode
                    }
                }
                Text(
                    when (lyricMode) {
                        AppPrefs.LYRIC_MODE_MERGED -> "原文与翻译逐行合并显示"
                        AppPrefs.LYRIC_MODE_RAW -> "仅显示原文歌词"
                        AppPrefs.LYRIC_MODE_TRANSLATED -> "仅显示翻译歌词"
                        else -> ""
                    },
                    modifier = Modifier.padding(start = 16.dp),
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = lyricApiBaseUrl,
                    onValueChange = { lyricApiBaseUrl = it; AppPrefs.lyricApiBaseUrl = it },
                    label = { Text("API 地址 *") },
                    placeholder = { Text("https://your-api-domain.com") },
                    supportingText = {
                        Text(
                            "必填，需自行搭建 NeteaseCloudMusicApiEnhanced 服务\n参考: github.com/NeteaseCloudMusicApiEnhanced/api-enhanced",
                            fontSize = 11.sp
                        )
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() })
                )

                OutlinedTextField(
                    value = lyricRealIP,
                    onValueChange = { lyricRealIP = it; AppPrefs.lyricRealIP = it },
                    label = { Text("Real IP") },
                    placeholder = { Text("可选，如 36.149.92.99") },
                    supportingText = {
                        Text(
                            "留空则不传递 realIP 参数（部分 API 部署需要此参数）",
                            fontSize = 11.sp
                        )
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() })
                )
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        title,
        modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp),
        fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
        letterSpacing = 1.sp
    )
}

@Composable
private fun RowScope.ThemeChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected, onClick = onClick,
        label = { Text(label, fontSize = 13.sp) },
        modifier = Modifier.weight(1f)
    )
}

@Composable
private fun RowScope.LyricModeChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected, onClick = onClick,
        label = { Text(label, fontSize = 13.sp) },
        modifier = Modifier.weight(1f)
    )
}

@Composable
private fun SettingSwitch(title: String, subtitle: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable { onCheckedChange(!checked) }.padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
            Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
