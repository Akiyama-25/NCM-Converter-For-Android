package com.example.ncmconverter.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

val Error = Color(0xFFCF6679)
val ErrorLight = Color(0xFFB3261E)
val Success = Color(0xFF4CAF50)

val DarkScheme = darkColorScheme(
    primary = Color(0xFF1DB954),
    onPrimary = Color(0xFF121212),
    surface = Color(0xFF121212),
    onSurface = Color(0xFFE0E0E0),
    surfaceVariant = Color(0xFF1E1E1E),
    onSurfaceVariant = Color(0xFFA0A0A0),
    error = Error
)

val LightScheme = lightColorScheme(
    primary = Color(0xFF1DB954),
    onPrimary = Color.White,
    surface = Color(0xFFFAFAFA),
    onSurface = Color(0xFF1C1B1F),
    surfaceVariant = Color(0xFFF0F0F0),
    onSurfaceVariant = Color(0xFF666666),
    error = ErrorLight
)

fun resolveColorScheme(darkTheme: Boolean): ColorScheme =
    if (darkTheme) DarkScheme else LightScheme
