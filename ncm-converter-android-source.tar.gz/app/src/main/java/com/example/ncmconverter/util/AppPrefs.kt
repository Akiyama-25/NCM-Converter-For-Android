package com.example.ncmconverter.util

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object AppPrefs {
    private const val NAME = "ncm_converter_prefs"
    private const val KEY_THEME_MODE = "theme_mode"
    private const val KEY_CUSTOM_PATH = "custom_path"
    private const val KEY_MANUAL_SAVE = "manual_save"
    private const val KEY_ENABLE_LYRIC = "enable_lyric"
    private const val KEY_LYRIC_MODE = "lyric_mode"
    private const val KEY_LYRIC_API_BASE_URL = "lyric_api_base_url"
    private const val KEY_LYRIC_REAL_IP = "lyric_real_ip"

    const val THEME_SYSTEM = "system"
    const val THEME_LIGHT = "light"
    const val THEME_DARK = "dark"

    const val LYRIC_MODE_MERGED = "merged"
    const val LYRIC_MODE_RAW = "raw"
    const val LYRIC_MODE_TRANSLATED = "translated"

    private lateinit var prefs: SharedPreferences

    private val _themeFlow = MutableStateFlow(THEME_SYSTEM)
    val themeFlow: StateFlow<String> = _themeFlow.asStateFlow()

    fun init(context: Context) {
        prefs = context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
        _themeFlow.value = themeMode // sync initial state
    }

    var themeMode: String
        get() = prefs.getString(KEY_THEME_MODE, THEME_SYSTEM) ?: THEME_SYSTEM
        set(value) {
            prefs.edit().putString(KEY_THEME_MODE, value).apply()
            _themeFlow.value = value
        }

    var customPath: String
        get() = prefs.getString(KEY_CUSTOM_PATH, "Music/NCMConverter") ?: "Music/NCMConverter"
        set(value) = prefs.edit().putString(KEY_CUSTOM_PATH, value).apply()

    var manualSave: Boolean
        get() = prefs.getBoolean(KEY_MANUAL_SAVE, true)
        set(value) = prefs.edit().putBoolean(KEY_MANUAL_SAVE, value).apply()

    var enableLyric: Boolean
        get() = prefs.getBoolean(KEY_ENABLE_LYRIC, true)
        set(value) = prefs.edit().putBoolean(KEY_ENABLE_LYRIC, value).apply()

    var lyricMode: String
        get() = prefs.getString(KEY_LYRIC_MODE, LYRIC_MODE_MERGED) ?: LYRIC_MODE_MERGED
        set(value) = prefs.edit().putString(KEY_LYRIC_MODE, value).apply()

    var lyricApiBaseUrl: String
        get() = prefs.getString(KEY_LYRIC_API_BASE_URL, "") ?: ""
        set(value) = prefs.edit().putString(KEY_LYRIC_API_BASE_URL, value).apply()

    var lyricRealIP: String
        get() = prefs.getString(KEY_LYRIC_REAL_IP, "") ?: ""
        set(value) = prefs.edit().putString(KEY_LYRIC_REAL_IP, value).apply()
}
